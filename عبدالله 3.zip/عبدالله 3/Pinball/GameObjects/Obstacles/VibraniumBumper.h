#pragma once

#include "Obstacle.h" 

class VibraniumBumper : public Obstacle 
{
private:
	Vector2D center;
	float radius;
	bool collidedLastFrame;
public:
	VibraniumBumper(Vector2D center, float radius); //constructor
	void draw(Interface& interface) override;


	Vector2D collideWith(Ball& ball, float collisionTime) ;
	void updateScore(Ball& ball, Score& score)override;

};