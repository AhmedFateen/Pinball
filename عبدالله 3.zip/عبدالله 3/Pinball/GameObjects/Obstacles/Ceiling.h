#pragma once



#include "Obstacle.h"

// Represents a thin vertically infinite wall, on which the ball can bounce
class Ceiling : public Obstacle
{
private:
    float position;  // The vertical position of the ceiling
    bool collidedLastFrame;  // Whether or not the last frame was a collision (to prevent flapping)

public:
    Ceiling(float position);
    void draw(Interface& interface) override;
    Vector2D collideWith(Ball& ball, float collisionTime) override;

    void updateScore(Ball& ball, Score& score)override;

};

