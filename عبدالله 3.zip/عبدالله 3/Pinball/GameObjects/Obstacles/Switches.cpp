#include "Switches.h"

Switches::Switches(Vector2D position, float length):position(position), length(length) {}


void Switches::draw(Interface& interface)
{
	interface.drawSwitches(position,length);

}




Vector2D Switches::collideWith(Ball & ball, float collisionTime)
{
    return Vector2D {0, 0};  // Should be replaced with the actual collision logic
}

void Switches::updateScore(Ball& ball, Score& score)
{

}
