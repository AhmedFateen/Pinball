#pragma once
#include "Obstacle.h"

class  Collectables : public Obstacle
{
	private:
	Vector2D center;
	std::string text="CIE 202";
	unsigned fontSize;
	bool ballSteps;
	Vector2D bottomLeft,bottomRight,topLeft,TopRight; // bounds of the text; could use array instead but this way is more descriptive

	public:
		Collectables(Vector2D center,unsigned fontSize);
		void draw(Interface& interface) override;
		Vector2D collideWith(Ball& ball, float collisionTime) override;
		void updateScore(Ball& ball, Score& score)override;

};
