#pragma once

#include "Obstacle.h"

class PopBumper: public Obstacle
{
private:

	Vector2D center; // The position of the origin of the circle
	float radius;

	bool collidedLastFrame;
public:
	PopBumper(Vector2D center, float radius); //Constructor
	void draw(Interface& interface); // Draws a pop bumper
	Vector2D collideWith(Ball& ball, float collisionTime) override;
	void updateScore(Ball& ball, Score& score)override;
};
