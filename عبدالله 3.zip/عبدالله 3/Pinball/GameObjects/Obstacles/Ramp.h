#pragma once
// BONUS
#include "Obstacle.h"

class Ramp : public Obstacle
{
private:
	FlipperType type;
	Vector2D flipperPoint; // point closest to the flippers
	float height;

	bool collidedLastFrame;
public:
	Ramp(FlipperType type,float height);

	void draw(Interface& interface) override;

	Vector2D collideWith(Ball& ball, float collisionTime) override;

	void updateScore(Ball& ball, Score& score)override;


};
