#include "SpeedBooster.h"

SpeedBooster::SpeedBooster(Vector2D center, float radius) : center(center), radius(radius) {}


void SpeedBooster::draw(Interface& interface)
{
	interface.drawSpeedBooster(center, radius);
}
Vector2D SpeedBooster::collideWith(Ball& ball, float collisionTime)
{
	if (!collidedLastFrame)
	{
		float distanceToBall = distance2points(center,ball.getCenter());
		if (distanceToBall - radius < ball.getRadius())
		{
			collidedLastFrame = true;

			return Vector2D { ball.getVelocity() * 0.4f } / collisionTime; // we keep it low because more than one collision is detected 
		}
	}
	collidedLastFrame = false;

	return { 0,0 }; // if no collision
}

void SpeedBooster::updateScore(Ball& ball, Score& score)
{

}
