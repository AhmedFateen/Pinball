#pragma once
#include "Obstacle.h" 
class ThrustBumper :public Obstacle
{
private:
	Vector2D center;
	float radius;
	float speedingFactor;
	bool collidedLastFrame;

public:
	ThrustBumper(Vector2D center, float radius,float speedingFactor); //constructor
	void draw(Interface& interface) override;
	Vector2D collideWith(Ball& ball, float collisionTime);
	void updateScore(Ball& ball, Score& score)override;

}; 