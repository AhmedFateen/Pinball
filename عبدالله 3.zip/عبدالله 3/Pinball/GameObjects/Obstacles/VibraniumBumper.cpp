#include "VibraniumBumper.h"

VibraniumBumper::VibraniumBumper(Vector2D center, float radius): center(center), radius(radius), collidedLastFrame(false) {}

Vector2D VibraniumBumper::collideWith(Ball& ball, float collisionTime)
{
	if (!collidedLastFrame)
	{
		float distanceToBall = distance2points(center,ball.getCenter());
		if (distanceToBall - radius <= ball.getRadius())
		{
			collidedLastFrame = true;

			return Vector2D{ ball.getVelocity() * -1.f } / collisionTime;
		}
	}
		collidedLastFrame = false;

		return { 0,0 }; // if no collision
	
}
void VibraniumBumper::draw(Interface& interface)
{
    interface.drawVibraniumBumper(center, radius);
}
void VibraniumBumper::updateScore(Ball& ball, Score& score)
{

}
