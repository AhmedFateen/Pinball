#pragma once

#include "Obstacle.h"

class Kickers :public Obstacle
{
private:

	Vector2D position;
	
public:

	Kickers(Vector2D position);       //constructor


	void draw(Interface& interface) override;

	Vector2D collideWith(Ball & ball, float collisionTime) override;

	void updateScore(Ball& ball, Score& score)override;


};