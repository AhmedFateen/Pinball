#pragma once

#include "Obstacle.h"

class SpeedBooster : public Obstacle
{
private:
	Vector2D center;
	float radius;
	bool  collidedLastFrame;
public:
	SpeedBooster(Vector2D center, float radius); //Constructor
	void draw(Interface& interface) override; // Draws a speed booster
	Vector2D collideWith(Ball& ball, float collisionTime) override;
	void updateScore(Ball& ball, Score& score)override;

};
