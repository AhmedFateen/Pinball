#include "Kickers.h"

Kickers::Kickers(Vector2D position):position(position){}


Vector2D Kickers::collideWith(Ball& ball, float collisionTime)
{
        return Vector2D{ 0, 0 };            // should be replaced by collision logic
}

void Kickers::draw(Interface &interface)
{
	interface.drawKickers(position);
}
void Kickers::updateScore(Ball& ball, Score& score)
{

}
