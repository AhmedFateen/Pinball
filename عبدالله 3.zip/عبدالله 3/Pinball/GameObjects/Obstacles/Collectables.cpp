#include "Collectables.h"

Collectables::Collectables(Vector2D center, unsigned fontSize) : center(center), fontSize(fontSize), ballSteps(false) {}

void Collectables::draw(Interface& interface)
{
	interface.drawCollectables(center, text, fontSize, ballSteps,bottomLeft,bottomRight,topLeft,TopRight);
}

Vector2D Collectables::collideWith(Ball& ball, float collisionTime)
{
	return { 0,0 };
}
void Collectables::updateScore(Ball& ball, Score& score)
{
	if (ball.getCenter().x > bottomLeft.x && ball.getCenter().x < bottomRight.x && ball.getCenter().y>topLeft.y && ball.getCenter().y < bottomLeft.y)
	{
		ballSteps = true;
		score.setScore(score.getScore()+5);
	}
	else
	{
		ballSteps = false;
	}
}

